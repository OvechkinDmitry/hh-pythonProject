from django.contrib import admin
from .models import *

admin.site.register(Demand)
admin.site.register(Geography)
admin.site.register(Skills)
admin.site.register(AboutPage)
admin.site.register(IntroCards)
admin.site.register(IntroFacts)